#!/usr/bin/env python

def main():
    print('Welcome to the Brain Games!')


if __name__ == '__main__':
    main()

from brain_gamess.cil import welcome_user

welcome_user()
